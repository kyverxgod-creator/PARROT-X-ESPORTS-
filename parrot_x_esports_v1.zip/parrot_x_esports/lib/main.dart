import 'package:flutter/material.dart';

void main() => runApp(const ParrotXEsportsApp());

class ParrotXEsportsApp extends StatelessWidget {
  const ParrotXEsportsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Parrot x eSports',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090A0F),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7C4DFF), brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class Tournament {
  final String mode;
  final String title;
  final String time;
  final int slots;
  final int booked;
  final String reward;

  const Tournament({required this.mode, required this.title, required this.time, required this.slots, required this.booked, required this.reward});
}

const tournaments = <Tournament>[
  Tournament(mode: 'BR Squad', title: 'BR Squad • Classic', time: 'Today • 7:15 PM', slots: 48, booked: 21, reward: 'Top 3 leaderboard'),
  Tournament(mode: 'BR Duo', title: 'BR Duo • Classic', time: 'Today • 8:00 PM', slots: 24, booked: 9, reward: 'Top 3 leaderboard'),
  Tournament(mode: 'BR Solo', title: 'BR Solo • Classic', time: 'Today • 8:45 PM', slots: 48, booked: 30, reward: 'Top 3 leaderboard'),
  Tournament(mode: 'CS 2v2 Head', title: 'CS 2v2 • Head', time: 'Tomorrow • 7:15 PM', slots: 16, booked: 5, reward: 'Winner leaderboard'),
  Tournament(mode: 'CS 2v2 Body', title: 'CS 2v2 • Body', time: 'Tomorrow • 8:00 PM', slots: 16, booked: 3, reward: 'Winner leaderboard'),
  Tournament(mode: 'Lone Wolf 1v1', title: 'Lone Wolf • 1v1', time: 'Tomorrow • 8:45 PM', slots: 16, booked: 11, reward: 'Winner leaderboard'),
  Tournament(mode: 'Lone Wolf 2v2', title: 'Lone Wolf • 2v2', time: 'Tomorrow • 9:30 PM', slots: 16, booked: 4, reward: 'Winner leaderboard'),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final joined = <String>{};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Parrot x eSports', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(onPressed: () => _showProfile(context), icon: const Icon(Icons.person_outline)),
        ],
      ),
      body: IndexedStack(index: tab, children: [
        _home(),
        _matches(),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'Tournaments'),
          NavigationDestination(icon: Icon(Icons.confirmation_num_outlined), selectedIcon: Icon(Icons.confirmation_num), label: 'My Matches'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFF5E35B1), Color(0xFF7E57C2)])),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('FREE FIRE TOURNAMENTS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
          SizedBox(height: 8),
          Text('Play. Compete. Rise.', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
          SizedBox(height: 6),
          Text('Choose a mode and reserve your tournament slot.'),
        ]),
      ),
      const SizedBox(height: 22),
      const Text('Available tournaments', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      ...tournaments.map(_card),
    ],
  );

  Widget _card(Tournament t) {
    final isJoined = joined.contains(t.title);
    final remaining = t.slots - t.booked - (isJoined ? 1 : 0);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: const Color(0xFF252033), borderRadius: BorderRadius.circular(8)), child: Text(t.mode, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))),
            const Spacer(),
            Text('$remaining slots left', style: TextStyle(color: remaining <= 4 ? Colors.orangeAccent : Colors.greenAccent, fontSize: 12, fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 10),
          Text(t.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          Text(t.time, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 5),
          Text(t.reward, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            onPressed: isJoined ? null : () => _join(t),
            icon: Icon(isJoined ? Icons.check : Icons.event_available),
            label: Text(isJoined ? 'Joined' : 'Reserve Slot'),
          )),
        ]),
      ),
    );
  }

  Widget _matches() {
    final my = tournaments.where((t) => joined.contains(t.title)).toList();
    if (my.isEmpty) return const Center(child: Text('No matches joined yet.'));
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('My Matches', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      ...my.map((t) => Card(child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.sports_esports)),
        title: Text(t.title), subtitle: Text('${t.time}\nRoom details will appear 5 minutes before match time.'), isThreeLine: true,
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showMatch(context, t),
      ))),
    ]);
  }

  void _join(Tournament t) {
    setState(() => joined.add(t.title));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Slot reserved for ${t.title}')));
  }

  void _showMatch(BuildContext context, Tournament t) {
    showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(t.title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Text(t.time),
      const SizedBox(height: 14),
      const Text('Room ID & Password', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 4),
      const Text('Admin will publish the room details 5 minutes before the match.'),
      const SizedBox(height: 20),
    ]));
  }

  void _showProfile(BuildContext context) => showDialog(context: context, builder: (_) => AlertDialog(
    title: const Text('Player Profile'),
    content: const Text('Parrot x eSports\n\nAccount system will be connected in the next build.'),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
  ));
}
