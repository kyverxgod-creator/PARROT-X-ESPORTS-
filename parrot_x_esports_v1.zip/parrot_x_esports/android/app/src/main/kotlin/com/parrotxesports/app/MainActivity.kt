package com.parrotxesports.app
import io.flutter.embedding.android.FlutterActivity
class MainActivity : FlutterActivity()
