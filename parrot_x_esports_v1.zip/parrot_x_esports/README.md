# Parrot x eSports

Real Flutter Android project starter for the Parrot x eSports tournament-management app.

## Current build
- Free Fire tournament modes
- Tournament cards
- Slot reservation state
- My Matches
- Room details placeholder with 5-minute release rule
- Android APK GitHub Actions workflow

## Next production steps
1. Add Firebase Authentication.
2. Add Firestore tournaments, players, slots and results.
3. Add secure admin authentication and admin dashboard.
4. Implement server-side room reveal timing.
5. Add push notifications.
6. Add production signing/keystore before release.

No real-money entry, wallet, deposits, withdrawals or prize payments are included in this starter.
